import { useCallback, useEffect, useState } from 'react';
import { supabase } from './supabase';

export function useCrud<T extends { id: string }>(table: string, orderBy: string = 'created_at') {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    const { data, error: err } = await supabase.from(table).select('*').order(orderBy, { ascending: false });
    if (err) {
      setError(err.message);
    } else {
      setItems((data as T[]) || []);
    }
    setLoading(false);
  }, [table, orderBy]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const insert = useCallback(
    async (values: Partial<T>) => {
      const { error: err } = await supabase.from(table).insert(values);
      if (err) throw err;
      await refresh();
    },
    [table, refresh]
  );

  const update = useCallback(
    async (id: string, values: Partial<T>) => {
      const { error: err } = await supabase.from(table).update(values).eq('id', id);
      if (err) throw err;
      await refresh();
    },
    [table, refresh]
  );

  const remove = useCallback(
    async (id: string) => {
      const { error: err } = await supabase.from(table).delete().eq('id', id);
      if (err) throw err;
      await refresh();
    },
    [table, refresh]
  );

  return { items, loading, error, refresh, insert, update, remove };
}
