export interface Supplier {
  id: string;
  name: string;
  phone: string | null;
  notes: string | null;
  created_at: string;
}

export interface Ingredient {
  id: string;
  name: string;
  unit: string;
  stock: number;
  cost_per_unit: number;
  low_stock_threshold: number;
  created_at: string;
}

export interface Recipe {
  id: string;
  name: string;
  category: string;
  price: number;
  created_at: string;
}

export interface RecipeIngredient {
  id: string;
  recipe_id: string;
  ingredient_id: string;
  quantity: number;
}

export interface Sale {
  id: string;
  sale_date: string;
  recipe_id: string | null;
  item_name: string;
  quantity: number;
  unit_price: number;
  total: number;
  created_at: string;
}

export interface Expense {
  id: string;
  expense_date: string;
  category: string;
  description: string;
  amount: number;
  created_at: string;
}

export interface Purchase {
  id: string;
  purchase_date: string;
  supplier_id: string | null;
  ingredient_id: string | null;
  quantity: number;
  unit_cost: number;
  total: number;
  created_at: string;
}

export const EXPENSE_CATEGORIES = [
  'رواتب',
  'إيجار',
  'كهرباء ومياه',
  'مشتريات غذائية',
  'صيانة',
  'تسويق',
  'أخرى',
];

export const RECIPE_CATEGORIES = [
  'أطباق رئيسية',
  'مقبلات',
  'مشروبات',
  'حلويات',
];

export const UNITS = ['كجم', 'جرام', 'لتر', 'مل', 'حبة', 'علبة', 'كيس'];
