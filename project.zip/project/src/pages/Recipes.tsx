import { useEffect, useMemo, useState } from 'react';
import { Plus, Trash2, Pencil, ChefHat } from 'lucide-react';
import { useCrud } from '@/lib/useCrud';
import { supabase } from '@/lib/supabase';
import { Recipe, RecipeIngredient, Ingredient, RECIPE_CATEGORIES } from '@/lib/types';
import { formatCurrency } from '@/lib/format';
import Modal from '@/components/Modal';
import { Field, Input, Button, Select } from '@/components/ui';

interface Row {
  ingredient_id: string;
  quantity: string;
}

export default function Recipes() {
  const { items: recipes, loading, insert, update, remove } = useCrud<Recipe>('recipes', 'created_at');
  const { items: ingredients } = useCrud<Ingredient>('ingredients', 'name');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Recipe | null>(null);
  const [saving, setSaving] = useState(false);
  const [rows, setRows] = useState<Row[]>([]);
  const [form, setForm] = useState({ name: '', category: RECIPE_CATEGORIES[0], price: '' });

  const costMap = useMemo(() => {
    const m: Record<string, number> = {};
    for (const ing of ingredients) m[ing.id] = Number(ing.cost_per_unit);
    return m;
  }, [ingredients]);

  const recipeCost = (recipeId: string) =>
    rowsCache[recipeId]?.reduce((a, r) => a + (Number(r.quantity) || 0) * (costMap[r.ingredient_id] || 0), 0) || 0;

  const [rowsCache, setRowsCache] = useState<Record<string, Row[]>>({});

  const loadRows = async (recipeId: string): Promise<Row[]> => {
    const { data } = await supabase.from('recipe_ingredients').select('*').eq('recipe_id', recipeId);
    const list = (data as RecipeIngredient[]) || [];
    return list.map((r) => ({ ingredient_id: r.ingredient_id, quantity: String(r.quantity) }));
  };

  const setCacheFromDb = async () => {
    const { data } = await supabase.from('recipe_ingredients').select('*');
    const list = (data as RecipeIngredient[]) || [];
    const cache: Record<string, Row[]> = {};
    for (const r of list) {
      (cache[r.recipe_id] = cache[r.recipe_id] || []).push({ ingredient_id: r.ingredient_id, quantity: String(r.quantity) });
    }
    setRowsCache(cache);
  };

  useEffect(() => {
    setCacheFromDb();
  }, [recipes.length]);

  const openNew = () => {
    setEditing(null);
    setForm({ name: '', category: RECIPE_CATEGORIES[0], price: '' });
    setRows([]);
    setOpen(true);
  };

  const openEdit = async (r: Recipe) => {
    setEditing(r);
    setForm({ name: r.name, category: r.category, price: String(r.price) });
    setRows(await loadRows(r.id));
    setOpen(true);
  };

  const addRow = () => setRows((rs) => [...rs, { ingredient_id: '', quantity: '' }]);

  const save = async () => {
    if (!form.name) return;
    setSaving(true);
    try {
      let recipeId = editing?.id || '';
      const values = { name: form.name, category: form.category, price: Number(form.price) || 0 };
      if (editing) {
        await update(editing.id, values);
      } else {
        const { data, error } = await supabase.from('recipes').insert(values).select('id').single();
        if (error) throw error;
        recipeId = (data as { id: string }).id;
      }
      await supabase.from('recipe_ingredients').delete().eq('recipe_id', recipeId);
      const valid = rows.filter((r) => r.ingredient_id && Number(r.quantity) > 0);
      if (valid.length > 0) {
        await supabase.from('recipe_ingredients').insert(
          valid.map((r) => ({ recipe_id: recipeId, ingredient_id: r.ingredient_id, quantity: Number(r.quantity) }))
        );
      }
      setOpen(false);
      await setCacheFromDb();
    } catch (e) {
      alert('حدث خطأ أثناء الحفظ: ' + (e instanceof Error ? e.message : ''));
    } finally {
      setSaving(false);
    }
  };

  const deleteRecipe = async (r: Recipe) => {
    if (!confirm('حذف هذا الطبق؟ سيتم حذف مكوناته أيضاً.')) return;
    try {
      await remove(r.id);
      await setCacheFromDb();
    } catch (e) {
      alert('حدث خطأ أثناء الحذف: ' + (e instanceof Error ? e.message : ''));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">الوصفات</h2>
          <p className="mt-1 text-sm text-slate-500">أطباق المطعم وتكلفة مكوناتها</p>
        </div>
        <Button onClick={openNew}>
          <Plus className="h-4 w-4" /> إضافة طبق
        </Button>
      </div>

      {loading ? (
        <div className="flex h-40 items-center justify-center">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-emerald-200 border-t-emerald-600" />
        </div>
      ) : recipes.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-12 text-center text-slate-400">
          لا توجد أطباق بعد — أضف أول طبق للبدء
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {recipes.map((r) => {
            const cost = recipeCost(r.id);
            const margin = Number(r.price) > 0 ? ((Number(r.price) - cost) / Number(r.price)) * 100 : 0;
            return (
              <div key={r.id} className="group rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition hover:shadow-md">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
                      <ChefHat className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800">{r.name}</h3>
                      <span className="text-xs font-medium text-slate-400">{r.category}</span>
                    </div>
                  </div>
                  <div className="flex gap-1 opacity-0 transition group-hover:opacity-100">
                    <button onClick={() => openEdit(r)} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-emerald-600">
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button onClick={() => deleteRecipe(r)} className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-xl bg-slate-50 px-2 py-2.5">
                    <p className="text-xs text-slate-400">سعر البيع</p>
                    <p className="text-sm font-bold text-slate-700">{formatCurrency(r.price)}</p>
                  </div>
                  <div className="rounded-xl bg-slate-50 px-2 py-2.5">
                    <p className="text-xs text-slate-400">التكلفة</p>
                    <p className="text-sm font-bold text-slate-700">{formatCurrency(cost)}</p>
                  </div>
                  <div className="rounded-xl bg-emerald-50 px-2 py-2.5">
                    <p className="text-xs text-emerald-600/70">الهامش</p>
                    <p className="text-sm font-bold text-emerald-700">{margin.toFixed(0)}%</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={open} title={editing ? 'تعديل طبق' : 'إضافة طبق'} onClose={() => setOpen(false)}>
        <div className="space-y-4">
          <Field label="اسم الطبق">
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثال: شاورما دجاج" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="التصنيف">
              <Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {RECIPE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </Select>
            </Field>
            <Field label="سعر البيع">
              <Input type="number" min="0" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
            </Field>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-600">المكونات</span>
              <button onClick={addRow} className="flex items-center gap-1 rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-200">
                <Plus className="h-3.5 w-3.5" /> إضافة مكوّن
              </button>
            </div>
            {rows.length === 0 && <p className="text-xs text-slate-400">لم تُضف مكونات بعد — التكلفة ستكون صفراً</p>}
            {rows.map((row, idx) => {
              const ing = ingredients.find((i) => i.id === row.ingredient_id);
              return (
                <div key={idx} className="flex items-center gap-2">
                  <Select
                    value={row.ingredient_id}
                    onChange={(e) => setRows((rs) => rs.map((r, i) => (i === idx ? { ...r, ingredient_id: e.target.value } : r)))}
                    className="flex-1"
                  >
                    <option value="">اختر المكوّن</option>
                    {ingredients.map((i) => (
                      <option key={i.id} value={i.id}>{i.name} ({i.unit})</option>
                    ))}
                  </Select>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="الكمية"
                    value={row.quantity}
                    onChange={(e) => setRows((rs) => rs.map((r, i) => (i === idx ? { ...r, quantity: e.target.value } : r)))}
                    className="w-24"
                  />
                  <span className="w-16 shrink-0 text-xs text-slate-400">{ing ? `${((Number(row.quantity) || 0) * Number(ing.cost_per_unit)).toFixed(1)}` : ''}</span>
                  <button
                    onClick={() => setRows((rs) => rs.filter((_, i) => i !== idx))}
                    className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
            <div className="rounded-xl bg-emerald-50 px-4 py-2.5 text-sm font-semibold text-emerald-700">
              تكلفة المكونات: {formatCurrency(rows.reduce((a, r) => a + (Number(r.quantity) || 0) * (costMap[r.ingredient_id] || 0), 0))}
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} disabled={saving || !form.name}>{saving ? 'جارٍ الحفظ…' : 'حفظ'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
