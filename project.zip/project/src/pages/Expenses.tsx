import { useState } from 'react';
import { Plus, Trash2, Pencil } from 'lucide-react';
import { useCrud } from '@/lib/useCrud';
import { Expense, EXPENSE_CATEGORIES } from '@/lib/types';
import { formatCurrency, formatDate, todayISO } from '@/lib/format';
import Modal from '@/components/Modal';
import { Field, Input, Button, Select } from '@/components/ui';

export default function Expenses() {
  const { items, loading, insert, update, remove } = useCrud<Expense>('expenses', 'expense_date');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Expense | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ expense_date: todayISO(), category: EXPENSE_CATEGORIES[0], description: '', amount: '' });

  const openNew = () => {
    setEditing(null);
    setForm({ expense_date: todayISO(), category: EXPENSE_CATEGORIES[0], description: '', amount: '' });
    setOpen(true);
  };

  const openEdit = (x: Expense) => {
    setEditing(x);
    setForm({ expense_date: x.expense_date, category: x.category, description: x.description, amount: String(x.amount) });
    setOpen(true);
  };

  const save = async () => {
    if (!form.amount) return;
    setSaving(true);
    try {
      const values = {
        expense_date: form.expense_date || todayISO(),
        category: form.category,
        description: form.description,
        amount: Number(form.amount) || 0,
      };
      if (editing) await update(editing.id, values);
      else await insert(values);
      setOpen(false);
    } catch (e) {
      alert('حدث خطأ أثناء الحفظ: ' + (e instanceof Error ? e.message : ''));
    } finally {
      setSaving(false);
    }
  };

  const total = items.reduce((a, x) => a + Number(x.amount), 0);
  const byCategory = EXPENSE_CATEGORIES.map((c) => ({
    cat: c,
    total: items.filter((x) => x.category === c).reduce((a, x) => a + Number(x.amount), 0),
  })).filter((x) => x.total > 0);
  const maxCat = Math.max(...byCategory.map((x) => x.total), 1);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">المصروفات</h2>
          <p className="mt-1 text-sm text-slate-500">الإجمالي: {formatCurrency(total)}</p>
        </div>
        <Button onClick={openNew}>
          <Plus className="h-4 w-4" /> إضافة مصروف
        </Button>
      </div>

      {byCategory.length > 0 && (
        <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
          <h3 className="mb-4 font-bold text-slate-700">المصروفات حسب التصنيف</h3>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {byCategory.map(({ cat, total: t }) => (
              <div key={cat}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="font-medium text-slate-600">{cat}</span>
                  <span className="text-slate-500">{formatCurrency(t)}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full rounded-full bg-gradient-to-l from-rose-400 to-rose-500 transition-all duration-500" style={{ width: `${(t / maxCat) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-4 py-3 text-right font-semibold">التاريخ</th>
                <th className="px-4 py-3 text-right font-semibold">التصنيف</th>
                <th className="px-4 py-3 text-right font-semibold">الوصف</th>
                <th className="px-4 py-3 text-right font-semibold">المبلغ</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {loading ? (
                <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-400">جارٍ التحميل…</td></tr>
              ) : items.length === 0 ? (
                <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-400">لا توجد مصروفات مسجلة بعد</td></tr>
              ) : (
                items.map((x) => (
                  <tr key={x.id} className="transition hover:bg-slate-50/70">
                    <td className="px-4 py-3 text-slate-600">{formatDate(x.expense_date)}</td>
                    <td className="px-4 py-3">
                      <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600">{x.category}</span>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{x.description || '—'}</td>
                    <td className="px-4 py-3 font-bold text-rose-600">{formatCurrency(x.amount)}</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => openEdit(x)} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-emerald-600">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => { if (confirm('حذف هذا المصروف؟')) remove(x.id); }}
                          className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={open} title={editing ? 'تعديل مصروف' : 'إضافة مصروف'} onClose={() => setOpen(false)}>
        <div className="space-y-4">
          <Field label="التاريخ">
            <Input type="date" value={form.expense_date} onChange={(e) => setForm({ ...form, expense_date: e.target.value })} />
          </Field>
          <Field label="التصنيف">
            <Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {EXPENSE_CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </Select>
          </Field>
          <Field label="الوصف">
            <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="وصف مختصر" />
          </Field>
          <Field label="المبلغ">
            <Input type="number" min="0" step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
          </Field>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} disabled={saving || !form.amount}>{saving ? 'جارٍ الحفظ…' : 'حفظ'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
