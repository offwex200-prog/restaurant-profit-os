import { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { formatCurrency, daysAgoISO } from '@/lib/format';
import { Sale, Expense, Purchase, Ingredient } from '@/lib/types';
import { DollarSign, TrendingDown, Percent, Package, TrendingUp, ShoppingCart, AlertTriangle } from 'lucide-react';

interface CardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  color: string;
}

function StatCard({ title, value, icon, color }: CardProps) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition hover:shadow-md">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500">{title}</p>
          <p className="mt-1 text-2xl font-bold text-slate-800">{value}</p>
        </div>
        <div className={`rounded-xl p-3 ${color}`}>{icon}</div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [sales, setSales] = useState<Sale[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [s, e, p, i] = await Promise.all([
          supabase.from('sales').select('*'),
          supabase.from('expenses').select('*'),
          supabase.from('purchases').select('*'),
          supabase.from('ingredients').select('*'),
        ]);
        if (s.error) throw s.error;
        if (e.error) throw e.error;
        if (p.error) throw p.error;
        if (i.error) throw i.error;
        setSales((s.data as Sale[]) || []);
        setExpenses((e.data as Expense[]) || []);
        setPurchases((p.data as Purchase[]) || []);
        setIngredients((i.data as Ingredient[]) || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'خطأ في تحميل البيانات');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const stats = useMemo(() => {
    const from = daysAgoISO(30);
    const recentSales = sales.filter((s) => s.sale_date >= from);
    const revenue = recentSales.reduce((a, s) => a + Number(s.total), 0);
    const monthlyExpenses = expenses
      .filter((e) => e.expense_date >= from)
      .reduce((a, e) => a + Number(e.amount), 0);
    const monthlyPurchases = purchases
      .filter((p) => p.purchase_date >= from)
      .reduce((a, p) => a + Number(p.total), 0);
    const profit = revenue - monthlyExpenses - monthlyPurchases;
    const margin = revenue > 0 ? (profit / revenue) * 100 : 0;
    const lowStock = ingredients.filter((i) => Number(i.stock) <= Number(i.low_stock_threshold));
    const topItems = Object.entries(
      sales.reduce<Record<string, number>>((acc, s) => {
        acc[s.item_name] = (acc[s.item_name] || 0) + Number(s.total);
        return acc;
      }, {})
    )
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
    const maxTop = topItems[0]?.[1] || 1;

    // last 14 days chart
    const days: { date: string; revenue: number }[] = [];
    for (let d = 13; d >= 0; d--) {
      const dt = daysAgoISO(d);
      days.push({
        date: dt,
        revenue: sales.filter((s) => s.sale_date === dt).reduce((a, s) => a + Number(s.total), 0),
      });
    }
    const maxRev = Math.max(...days.map((d) => d.revenue), 1);
    return { revenue, monthlyExpenses, monthlyPurchases, profit, margin, lowStock, topItems, maxTop, days, maxRev };
  }, [sales, expenses, purchases, ingredients]);

  if (loading)
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-emerald-200 border-t-emerald-600" />
      </div>
    );

  if (error)
    return (
      <div className="rounded-2xl border border-rose-200 bg-rose-50 p-5 text-sm font-medium text-rose-700">{error}</div>
    );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">لوحة التحكم</h2>
        <p className="mt-1 text-sm text-slate-500">نظرة عامة على أداء المطعم خلال آخر 30 يوماً</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="الإيرادات" value={formatCurrency(stats.revenue)} icon={<DollarSign className="h-6 w-6" />} color="bg-emerald-50 text-emerald-600" />
        <StatCard title="المصروفات" value={formatCurrency(stats.monthlyExpenses + stats.monthlyPurchases)} icon={<TrendingDown className="h-6 w-6" />} color="bg-rose-50 text-rose-600" />
        <StatCard title="صافي الربح" value={formatCurrency(stats.profit)} icon={<TrendingUp className="h-6 w-6" />} color={stats.profit >= 0 ? 'bg-teal-50 text-teal-600' : 'bg-rose-50 text-rose-600'} />
        <StatCard title="هامش الربح" value={`${stats.margin.toFixed(1)}%`} icon={<Percent className="h-6 w-6" />} color="bg-amber-50 text-amber-600" />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm lg:col-span-2">
          <h3 className="mb-4 font-bold text-slate-700">الإيرادات اليومية (14 يوم)</h3>
          <div className="flex h-48 items-end gap-2" dir="ltr">
            {stats.days.map((d) => (
              <div key={d.date} className="group relative flex-1">
                <div
                  className="w-full rounded-t-lg bg-gradient-to-t from-emerald-600 to-emerald-400 transition-all duration-300 hover:from-emerald-700 hover:to-emerald-500"
                  style={{ height: `${Math.max((d.revenue / stats.maxRev) * 170, 4)}px` }}
                />
                <div className="pointer-events-none absolute -top-8 right-1/2 hidden translate-x-1/2 whitespace-nowrap rounded-lg bg-slate-800 px-2 py-1 text-xs text-white group-hover:block">
                  {formatCurrency(d.revenue)}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
          <h3 className="mb-4 font-bold text-slate-700">الأصناف الأكثر مبيعاً</h3>
          {stats.topItems.length === 0 ? (
            <p className="text-sm text-slate-400">لا توجد مبيعات بعد</p>
          ) : (
            <div className="space-y-3">
              {stats.topItems.map(([name, total], i) => (
                <div key={name}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="font-medium text-slate-600">{i + 1}. {name}</span>
                    <span className="text-slate-500">{formatCurrency(total)}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-gradient-to-l from-amber-400 to-amber-500 transition-all duration-500"
                      style={{ width: `${(total / stats.maxTop) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-amber-500" />
          <h3 className="font-bold text-slate-700">تنبيهات المخزون المنخفض</h3>
        </div>
        {stats.lowStock.length === 0 ? (
          <p className="text-sm text-slate-400">المخزون في حالة جيدة، لا توجد تنبيهات</p>
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {stats.lowStock.map((ing) => (
              <div key={ing.id} className="flex items-center justify-between rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
                <span className="text-sm font-semibold text-slate-700">{ing.name}</span>
                <span className="text-sm text-amber-700">{ing.stock} {ing.unit} متبقي</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
