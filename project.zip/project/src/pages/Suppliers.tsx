import { useState } from 'react';
import { Plus, Trash2, Pencil, Phone } from 'lucide-react';
import { useCrud } from '@/lib/useCrud';
import { Supplier } from '@/lib/types';
import Modal from '@/components/Modal';
import { Field, Input, Button, Textarea } from '@/components/ui';

export default function Suppliers() {
  const { items, loading, insert, update, remove } = useCrud<Supplier>('suppliers', 'created_at');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', notes: '' });

  const openNew = () => {
    setEditing(null);
    setForm({ name: '', phone: '', notes: '' });
    setOpen(true);
  };

  const openEdit = (s: Supplier) => {
    setEditing(s);
    setForm({ name: s.name, phone: s.phone || '', notes: s.notes || '' });
    setOpen(true);
  };

  const save = async () => {
    if (!form.name) return;
    setSaving(true);
    try {
      if (editing) await update(editing.id, form);
      else await insert(form);
      setOpen(false);
    } catch (e) {
      alert('حدث خطأ أثناء الحفظ: ' + (e instanceof Error ? e.message : ''));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">الموردون</h2>
          <p className="mt-1 text-sm text-slate-500">{items.length} مورد مسجل</p>
        </div>
        <Button onClick={openNew}>
          <Plus className="h-4 w-4" /> إضافة مورد
        </Button>
      </div>

      {loading ? (
        <div className="flex h-40 items-center justify-center">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-emerald-200 border-t-emerald-600" />
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-12 text-center text-slate-400">
          لا يوجد موردون بعد — أضف أول مورد للبدء
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((s) => (
            <div key={s.id} className="group rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald-50 text-lg font-bold text-emerald-700">
                    {s.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">{s.name}</h3>
                    {s.phone && (
                      <p className="mt-0.5 flex items-center gap-1 text-sm text-slate-500" dir="ltr">
                        <Phone className="h-3.5 w-3.5" /> {s.phone}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex gap-1 opacity-0 transition group-hover:opacity-100">
                  <button onClick={() => openEdit(s)} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-emerald-600">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => { if (confirm('حذف هذا المورد؟')) remove(s.id); }}
                    className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              {s.notes && <p className="mt-3 border-t border-slate-50 pt-3 text-sm leading-relaxed text-slate-500">{s.notes}</p>}
            </div>
          ))}
        </div>
      )}

      <Modal open={open} title={editing ? 'تعديل مورد' : 'إضافة مورد'} onClose={() => setOpen(false)}>
        <div className="space-y-4">
          <Field label="اسم المورد">
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثال: شركة اللحوم" />
          </Field>
          <Field label="رقم الهاتف">
            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="01xxxxxxxxx" dir="ltr" />
          </Field>
          <Field label="ملاحظات">
            <Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="ملاحظات إضافية" />
          </Field>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} disabled={saving || !form.name}>{saving ? 'جارٍ الحفظ…' : 'حفظ'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
