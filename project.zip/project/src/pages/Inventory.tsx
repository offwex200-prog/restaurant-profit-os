import { useState } from 'react';
import { Plus, Trash2, Pencil, AlertTriangle } from 'lucide-react';
import { useCrud } from '@/lib/useCrud';
import { Ingredient, UNITS } from '@/lib/types';
import { formatCurrency, formatNumber } from '@/lib/format';
import Modal from '@/components/Modal';
import { Field, Input, Button, Select } from '@/components/ui';

export default function Inventory() {
  const { items, loading, insert, update, remove } = useCrud<Ingredient>('ingredients', 'created_at');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Ingredient | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', unit: UNITS[0], stock: '', cost_per_unit: '', low_stock_threshold: '5' });

  const openNew = () => {
    setEditing(null);
    setForm({ name: '', unit: UNITS[0], stock: '', cost_per_unit: '', low_stock_threshold: '5' });
    setOpen(true);
  };

  const openEdit = (i: Ingredient) => {
    setEditing(i);
    setForm({ name: i.name, unit: i.unit, stock: String(i.stock), cost_per_unit: String(i.cost_per_unit), low_stock_threshold: String(i.low_stock_threshold) });
    setOpen(true);
  };

  const save = async () => {
    if (!form.name) return;
    setSaving(true);
    try {
      const values = {
        name: form.name,
        unit: form.unit,
        stock: Number(form.stock) || 0,
        cost_per_unit: Number(form.cost_per_unit) || 0,
        low_stock_threshold: Number(form.low_stock_threshold) || 0,
      };
      if (editing) await update(editing.id, values);
      else await insert(values);
      setOpen(false);
    } catch (e) {
      alert('حدث خطأ أثناء الحفظ: ' + (e instanceof Error ? e.message : ''));
    } finally {
      setSaving(false);
    }
  };

  const totalValue = items.reduce((a, i) => a + Number(i.stock) * Number(i.cost_per_unit), 0);
  const lowCount = items.filter((i) => Number(i.stock) <= Number(i.low_stock_threshold)).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">المخزون</h2>
          <p className="mt-1 text-sm text-slate-500">
            قيمة المخزون: {formatCurrency(totalValue)}{lowCount > 0 && ` • ${lowCount} صنف منخفض`}
          </p>
        </div>
        <Button onClick={openNew}>
          <Plus className="h-4 w-4" /> إضافة صنف
        </Button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-4 py-3 text-right font-semibold">الصنف</th>
                <th className="px-4 py-3 text-right font-semibold">الكمية المتوفرة</th>
                <th className="px-4 py-3 text-right font-semibold">تكلفة الوحدة</th>
                <th className="px-4 py-3 text-right font-semibold">القيمة</th>
                <th className="px-4 py-3 text-right font-semibold">الحالة</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {loading ? (
                <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-400">جارٍ التحميل…</td></tr>
              ) : items.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-400">لا توجد أصناف في المخزون بعد</td></tr>
              ) : (
                items.map((i) => {
                  const low = Number(i.stock) <= Number(i.low_stock_threshold);
                  return (
                    <tr key={i.id} className="transition hover:bg-slate-50/70">
                      <td className="px-4 py-3 font-medium text-slate-800">{i.name}</td>
                      <td className="px-4 py-3 text-slate-600">{formatNumber(i.stock)} {i.unit}</td>
                      <td className="px-4 py-3 text-slate-600">{formatCurrency(i.cost_per_unit)}</td>
                      <td className="px-4 py-3 font-semibold text-slate-700">{formatCurrency(Number(i.stock) * Number(i.cost_per_unit))}</td>
                      <td className="px-4 py-3">
                        {low ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700">
                            <AlertTriangle className="h-3 w-3" /> منخفض
                          </span>
                        ) : (
                          <span className="inline-flex rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">جيد</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-1">
                          <button onClick={() => openEdit(i)} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-emerald-600">
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => { if (confirm('حذف هذا الصنف؟')) remove(i.id); }}
                            className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={open} title={editing ? 'تعديل صنف' : 'إضافة صنف'} onClose={() => setOpen(false)}>
        <div className="space-y-4">
          <Field label="اسم الصنف">
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثال: دجاج" />
          </Field>
          <Field label="وحدة القياس">
            <Select value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })}>
              {UNITS.map((u) => (
                <option key={u} value={u}>{u}</option>
              ))}
            </Select>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الكمية المتوفرة">
              <Input type="number" min="0" step="0.01" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} />
            </Field>
            <Field label="تكلفة الوحدة">
              <Input type="number" min="0" step="0.01" value={form.cost_per_unit} onChange={(e) => setForm({ ...form, cost_per_unit: e.target.value })} />
            </Field>
          </div>
          <Field label="حد التنبيه للنقص">
            <Input type="number" min="0" step="0.01" value={form.low_stock_threshold} onChange={(e) => setForm({ ...form, low_stock_threshold: e.target.value })} />
          </Field>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} disabled={saving || !form.name}>{saving ? 'جارٍ الحفظ…' : 'حفظ'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
