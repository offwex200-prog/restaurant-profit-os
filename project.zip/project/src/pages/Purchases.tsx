import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { useCrud } from '@/lib/useCrud';
import { supabase } from '@/lib/supabase';
import { Purchase, Supplier, Ingredient } from '@/lib/types';
import { formatCurrency, formatDate, todayISO } from '@/lib/format';
import Modal from '@/components/Modal';
import { Field, Input, Button, Select } from '@/components/ui';

export default function Purchases() {
  const { items, loading, insert, remove } = useCrud<Purchase>('purchases', 'purchase_date');
  const { items: suppliers } = useCrud<Supplier>('suppliers', 'name');
  const { items: ingredients } = useCrud<Ingredient>('ingredients', 'name');
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [addToStock, setAddToStock] = useState(true);
  const [form, setForm] = useState({
    purchase_date: todayISO(),
    supplier_id: '',
    ingredient_id: '',
    quantity: '',
    unit_cost: '',
  });

  const openNew = () => {
    setForm({ purchase_date: todayISO(), supplier_id: '', ingredient_id: '', quantity: '', unit_cost: '' });
    setAddToStock(true);
    setOpen(true);
  };

  const save = async () => {
    if (!form.ingredient_id || !form.quantity) return;
    setSaving(true);
    try {
      const qty = Number(form.quantity) || 0;
      const cost = Number(form.unit_cost) || 0;
      const ing = ingredients.find((i) => i.id === form.ingredient_id);
      await insert({
        purchase_date: form.purchase_date || todayISO(),
        supplier_id: form.supplier_id || null,
        ingredient_id: form.ingredient_id,
        quantity: qty,
        unit_cost: cost,
        total: qty * cost,
      });
      if (addToStock && ing) {
        await supabase
          .from('ingredients')
          .update({ stock: Number(ing.stock) + qty, cost_per_unit: cost || Number(ing.cost_per_unit) })
          .eq('id', ing.id);
      }
      setOpen(false);
    } catch (e) {
      alert('حدث خطأ أثناء الحفظ: ' + (e instanceof Error ? e.message : ''));
    } finally {
      setSaving(false);
    }
  };

  const total = items.reduce((a, p) => a + Number(p.total), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">المشتريات</h2>
          <p className="mt-1 text-sm text-slate-500">الإجمالي: {formatCurrency(total)}</p>
        </div>
        <Button onClick={openNew}>
          <Plus className="h-4 w-4" /> إضافة فاتورة شراء
        </Button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-4 py-3 text-right font-semibold">التاريخ</th>
                <th className="px-4 py-3 text-right font-semibold">المورد</th>
                <th className="px-4 py-3 text-right font-semibold">الصنف</th>
                <th className="px-4 py-3 text-right font-semibold">الكمية</th>
                <th className="px-4 py-3 text-right font-semibold">سعر الوحدة</th>
                <th className="px-4 py-3 text-right font-semibold">الإجمالي</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {loading ? (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400">جارٍ التحميل…</td></tr>
              ) : items.length === 0 ? (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400">لا توجد مشتريات مسجلة بعد</td></tr>
              ) : (
                items.map((p) => {
                  const supplier = suppliers.find((s) => s.id === p.supplier_id);
                  const ing = ingredients.find((i) => i.id === p.ingredient_id);
                  return (
                    <tr key={p.id} className="transition hover:bg-slate-50/70">
                      <td className="px-4 py-3 text-slate-600">{formatDate(p.purchase_date)}</td>
                      <td className="px-4 py-3 text-slate-600">{supplier?.name || '—'}</td>
                      <td className="px-4 py-3 font-medium text-slate-800">{ing?.name || '—'}</td>
                      <td className="px-4 py-3 text-slate-600">{p.quantity} {ing?.unit || ''}</td>
                      <td className="px-4 py-3 text-slate-600">{formatCurrency(p.unit_cost)}</td>
                      <td className="px-4 py-3 font-bold text-rose-600">{formatCurrency(p.total)}</td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end">
                          <button
                            onClick={() => { if (confirm('حذف هذه الفاتورة؟')) remove(p.id); }}
                            className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={open} title="إضافة فاتورة شراء" onClose={() => setOpen(false)}>
        <div className="space-y-4">
          <Field label="التاريخ">
            <Input type="date" value={form.purchase_date} onChange={(e) => setForm({ ...form, purchase_date: e.target.value })} />
          </Field>
          <Field label="المورد">
            <Select value={form.supplier_id} onChange={(e) => setForm({ ...form, supplier_id: e.target.value })}>
              <option value="">بدون مورد</option>
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </Select>
          </Field>
          <Field label="الصنف">
            <Select value={form.ingredient_id} onChange={(e) => {
              const ing = ingredients.find((i) => i.id === e.target.value);
              setForm({ ...form, ingredient_id: e.target.value, unit_cost: ing ? String(ing.cost_per_unit) : '' });
            }}>
              <option value="">اختر الصنف</option>
              {ingredients.map((i) => (
                <option key={i.id} value={i.id}>{i.name}</option>
              ))}
            </Select>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الكمية">
              <Input type="number" min="0" step="0.01" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
            </Field>
            <Field label="سعر الوحدة">
              <Input type="number" min="0" step="0.01" value={form.unit_cost} onChange={(e) => setForm({ ...form, unit_cost: e.target.value })} />
            </Field>
          </div>
          <label className="flex items-center gap-2 text-sm text-slate-600">
            <input
              type="checkbox"
              checked={addToStock}
              onChange={(e) => setAddToStock(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
            />
            إضافة الكمية إلى المخزون تلقائياً
          </label>
          <div className="rounded-xl bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">
            الإجمالي: {formatCurrency((Number(form.quantity) || 0) * (Number(form.unit_cost) || 0))}
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} disabled={saving || !form.ingredient_id || !form.quantity}>{saving ? 'جارٍ الحفظ…' : 'حفظ'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
