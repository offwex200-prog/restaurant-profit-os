import { useState } from 'react';
import { Plus, Trash2, Pencil } from 'lucide-react';
import { useCrud } from '@/lib/useCrud';
import { Sale, Recipe } from '@/lib/types';
import { formatCurrency, formatDate, todayISO } from '@/lib/format';
import Modal from '@/components/Modal';
import { Field, Input, Button, Select } from '@/components/ui';

export default function Sales() {
  const { items: sales, loading, insert, update, remove } = useCrud<Sale>('sales', 'sale_date');
  const { items: recipes } = useCrud<Recipe>('recipes', 'name');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Sale | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ sale_date: todayISO(), recipe_id: '', item_name: '', quantity: '1', unit_price: '' });

  const openNew = () => {
    setEditing(null);
    setForm({ sale_date: todayISO(), recipe_id: '', item_name: '', quantity: '1', unit_price: '' });
    setOpen(true);
  };

  const openEdit = (s: Sale) => {
    setEditing(s);
    setForm({
      sale_date: s.sale_date,
      recipe_id: s.recipe_id || '',
      item_name: s.item_name,
      quantity: String(s.quantity),
      unit_price: String(s.unit_price),
    });
    setOpen(true);
  };

  const onRecipeChange = (id: string) => {
    const r = recipes.find((r) => r.id === id);
    setForm((f) => ({
      ...f,
      recipe_id: id,
      item_name: r ? r.name : f.item_name,
      unit_price: r ? String(r.price) : f.unit_price,
    }));
  };

  const save = async () => {
    if (!form.item_name || !form.quantity) return;
    setSaving(true);
    try {
      const qty = Number(form.quantity) || 0;
      const price = Number(form.unit_price) || 0;
      const values = {
        sale_date: form.sale_date || todayISO(),
        recipe_id: form.recipe_id || null,
        item_name: form.item_name,
        quantity: qty,
        unit_price: price,
        total: qty * price,
      };
      if (editing && editing.id) await update(editing.id, values);
      else await insert(values);
      setOpen(false);
    } catch (e) {
      alert('حدث خطأ أثناء الحفظ: ' + (e instanceof Error ? e.message : ''));
    } finally {
      setSaving(false);
    }
  };

  const total = sales.reduce((a, s) => a + Number(s.total), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">المبيعات</h2>
          <p className="mt-1 text-sm text-slate-500">الإجمالي: {formatCurrency(total)}</p>
        </div>
        <Button onClick={openNew}>
          <Plus className="h-4 w-4" /> إضافة بيع
        </Button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-4 py-3 text-right font-semibold">التاريخ</th>
                <th className="px-4 py-3 text-right font-semibold">الصنف</th>
                <th className="px-4 py-3 text-right font-semibold">الكمية</th>
                <th className="px-4 py-3 text-right font-semibold">سعر الوحدة</th>
                <th className="px-4 py-3 text-right font-semibold">الإجمالي</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {loading ? (
                <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-400">جارٍ التحميل…</td></tr>
              ) : sales.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-400">لا توجد مبيعات مسجلة بعد</td></tr>
              ) : (
                sales.map((s) => (
                  <tr key={s.id} className="transition hover:bg-slate-50/70">
                    <td className="px-4 py-3 text-slate-600">{formatDate(s.sale_date)}</td>
                    <td className="px-4 py-3 font-medium text-slate-800">{s.item_name}</td>
                    <td className="px-4 py-3 text-slate-600">{s.quantity}</td>
                    <td className="px-4 py-3 text-slate-600">{formatCurrency(s.unit_price)}</td>
                    <td className="px-4 py-3 font-bold text-emerald-700">{formatCurrency(s.total)}</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => openEdit(s)} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-emerald-600">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => { if (confirm('حذف هذا البيع؟')) remove(s.id); }}
                          className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={open} title={editing ? 'تعديل بيع' : 'إضافة بيع'} onClose={() => setOpen(false)}>
        <div className="space-y-4">
          <Field label="التاريخ">
            <Input type="date" value={form.sale_date} onChange={(e) => setForm({ ...form, sale_date: e.target.value })} />
          </Field>
          <Field label="الصنف من قائمة الأطباق (اختياري)">
            <Select value={form.recipe_id} onChange={(e) => onRecipeChange(e.target.value)}>
              <option value="">إدخال يدوي</option>
              {recipes.map((r) => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </Select>
          </Field>
          <Field label="اسم الصنف">
            <Input value={form.item_name} onChange={(e) => setForm({ ...form, item_name: e.target.value })} placeholder="مثال: شاورما دجاج" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الكمية">
              <Input type="number" min="1" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
            </Field>
            <Field label="سعر الوحدة">
              <Input type="number" min="0" step="0.01" value={form.unit_price} onChange={(e) => setForm({ ...form, unit_price: e.target.value })} />
            </Field>
          </div>
          <div className="rounded-xl bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">
            الإجمالي: {formatCurrency((Number(form.quantity) || 0) * (Number(form.unit_price) || 0))}
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} disabled={saving || !form.item_name}>{saving ? 'جارٍ الحفظ…' : 'حفظ'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
